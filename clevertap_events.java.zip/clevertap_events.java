package com.example.fcm;

import androidx.appcompat.app.AppCompatActivity;

import com.clevertap.android.sdk.CleverTapAPI;

import java.util.HashMap;

public class clevertap_events extends AppCompatActivity {
    CleverTapAPI clevertapDefaultInstance = CleverTapAPI.getDefaultInstance(getApplicationContext());

  public void Sign_Up(String Mode,String Status)
  {
      HashMap signup_hm=new HashMap();
      signup_hm.put("Mode",Mode);
      signup_hm.put("Status",Status);
      clevertapDefaultInstance.pushEvent("Sign Up",signup_hm);

  }
}
